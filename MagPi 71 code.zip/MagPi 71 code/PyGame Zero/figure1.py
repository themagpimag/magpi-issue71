WIDTH = 700 
HEIGHT = 800 

def draw(): 
    screen.fill((128, 128, 128))	

        
