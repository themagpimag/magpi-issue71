def makeTrack(): # Function to make a new section of track
    global trackCount, trackLeft, trackRight, trackPosition, trackWidth
    trackLeft.append(Actor("barrier", pos = (trackPosition-trackWidth,0)))
    trackRight.append(Actor("barrier", pos = (trackPosition+trackWidth,0)))
    trackCount += 1   


        
