# add this in at the very top, under print('Loading ....') along with the other libraries imported
import io
import tweepy
from google.cloud import vision
from google.cloud.vision import types
from google.cloud import storage