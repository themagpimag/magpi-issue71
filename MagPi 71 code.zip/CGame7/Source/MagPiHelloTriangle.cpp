/*
Simple example of a main function creating a game class and updating it
*/

#include "Game.h"
#include <stdio.h>
#include <iostream>
#include <streambuf>
#include <stdlib.h>
#include <string>
#include <sstream>

int main(int argc, char *argv[])
{
	
	
	Game TheGame; // create an instance of  game.
	
	TheGame.Update();

} 
